<!-- Подключаем JS -->
<script src="script.js"></script>
</body>
</html>
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('orderForm');
  const modalEl = document.getElementById('feedbackModal');
  const feedbackMessage = document.getElementById('feedbackMessage');
  // Bootstrap-объект модалки
  const feedbackModal = new bootstrap.Modal(modalEl);

  form.addEventListener('submit', function(e) {
    e.preventDefault(); // не перезагружать страницу

    const data = {
      name:   form.name.value.trim(),
      email:  form.email.value.trim(),
      phone:  form.phone.value.trim(),
      address: form.address?.value.trim() ?? '',
      product: form.product?.value ?? '',
      quantity: form.quantity?.value ?? ''
    };

    console.log('Отправка заказа:', data);

    if (!data.name || !data.email || !data.phone) {
      feedbackMessage.textContent = 'Пожалуйста, заполните все обязательные поля корректно.';
      feedbackModal.show();
      return;
    }

    feedbackMessage.textContent = 'Спасибо! Ваш заказ принят и обработан.';
    feedbackModal.show();

    // Очистка формы
    form.reset();
  });
});
// После DOMContentLoaded, внизу:
const searchInput = document.getElementById('searchInput');
if (searchInput) {
  const tableRows = document.querySelectorAll('#productsTable tbody tr');
  searchInput.addEventListener('input', () => {
    const term = searchInput.value.trim().toLowerCase();
    tableRows.forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(term) ? '' : 'none';
    });
  });
}

